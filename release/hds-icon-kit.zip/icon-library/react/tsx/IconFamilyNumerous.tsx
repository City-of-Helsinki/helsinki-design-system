import React from 'react';

import styles from './Icon.module.css';
import { IconProps, IconSize } from './Icon.interface';

export const IconFamilyNumerous = ({
  'aria-label': ariaLabel = 'family-numerous',
  'aria-hidden': ariaHidden = true,
  className = '',
  color,
  size = IconSize.Small,
  style = {},
  ...rest,
}: IconProps) => (
  <svg
    aria-label={ariaLabel}
    aria-hidden={ariaHidden}
    className={[styles.icon, styles[size], className].filter((e) => e).join(' ')}
    role="img"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    color={color}
    style={style}
    {...rest}
  >
    <g clipPath="url(#clip0_27516_315)">
<path d="M4 22H6V24H2V17H4V22Z" fill="currentColor"></path>
<path d="M10 12C10.7692 12 11.469 12.2916 12 12.7676C12.531 12.2916 13.2308 12 14 12H16C17.6569 12 19 13.3431 19 15V20H17V24H13V19H17V15C17 14.4477 16.5523 14 16 14H14C13.4477 14 13 14.4477 13 15V19H11V15C11 14.4477 10.5523 14 10 14H8C7.44772 14 7 14.4477 7 15V19H11V24H7V20H5V15C5 13.3432 6.34315 12 8 12H10Z" fill="currentColor"></path>
<path d="M22 24H18V22H20V17H22V24Z" fill="currentColor"></path>
<path d="M6.12793 7C5.73238 7.56697 5.5 8.25626 5.5 9L5.50098 9.00098L3.83008 9.00195C2.99256 9.03756 2.53037 9.51769 2.2832 10.4951L2 17H0L0.5 9C0.962785 7.16973 2.00913 7.00001 3.93262 7H6.12793Z" fill="currentColor"></path>
<path d="M20.0674 7C21.9909 7.00001 23.0372 7.16973 23.5 9L24 17H22L21.7168 10.4951C21.4696 9.51769 21.0074 9.03756 20.1699 9.00195L18.499 9.00098L18.5 9C18.5 8.25626 18.2676 7.56697 17.8721 7H20.0674Z" fill="currentColor"></path>
<path d="M9 6.5C10.3807 6.5 11.5 7.61929 11.5 9C11.5 10.3807 10.3807 11.5 9 11.5C7.61929 11.5 6.5 10.3807 6.5 9C6.5 7.61929 7.61929 6.5 9 6.5ZM9 8.5C8.72386 8.5 8.5 8.72386 8.5 9C8.5 9.27614 8.72386 9.5 9 9.5C9.27614 9.5 9.5 9.27614 9.5 9C9.5 8.72386 9.27614 8.5 9 8.5Z" fillRule="evenodd" clipRule="evenodd" fill="currentColor"></path>
<path d="M15 6.5C16.3807 6.5 17.5 7.61929 17.5 9C17.5 10.3807 16.3807 11.5 15 11.5C13.6193 11.5 12.5 10.3807 12.5 9C12.5 7.61929 13.6193 6.5 15 6.5ZM15 8.5C14.7239 8.5 14.5 8.72386 14.5 9C14.5 9.27614 14.7239 9.5 15 9.5C15.2761 9.5 15.5 9.27614 15.5 9C15.5 8.72386 15.2761 8.5 15 8.5Z" fillRule="evenodd" clipRule="evenodd" fill="currentColor"></path>
<path d="M6 0C7.65685 0 9 1.34315 9 3C9 4.65685 7.65685 6 6 6C4.34315 6 3 4.65685 3 3C3 1.34315 4.34315 0 6 0ZM6 2C5.44772 2 5 2.44772 5 3C5 3.55228 5.44772 4 6 4C6.55228 4 7 3.55228 7 3C7 2.44772 6.55228 2 6 2Z" fillRule="evenodd" clipRule="evenodd" fill="currentColor"></path>
<path d="M18 0C19.6569 0 21 1.34315 21 3C21 4.65685 19.6569 6 18 6C16.3431 6 15 4.65685 15 3C15 1.34315 16.3431 0 18 0ZM18 2C17.4477 2 17 2.44772 17 3C17 3.55228 17.4477 4 18 4C18.5523 4 19 3.55228 19 3C19 2.44772 18.5523 2 18 2Z" fillRule="evenodd" clipRule="evenodd" fill="currentColor"></path>
</g>
<defs>
<clipPath id="clip0_27516_315">
<rect width="24" height="24" fill="currentColor"></rect>
</clipPath>
</defs>
  </svg>
);
