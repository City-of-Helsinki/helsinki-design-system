import React from 'react';

import styles from './Icon.module.css';
import { IconProps, IconSize } from './Icon.interface';

export const IconCopy = ({
  'aria-label': ariaLabel = 'copy',
  'aria-hidden': ariaHidden = true,
  className = '',
  color,
  size = IconSize.Small,
  style = {},
  ...rest,
}: IconProps) => (
  <svg
    aria-label={ariaLabel}
    aria-hidden={ariaHidden}
    className={[styles.icon, styles[size], className].filter((e) => e).join(' ')}
    role="img"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    color={color}
    style={style}
    {...rest}
  >
    <path d="M6 10V12H5V18H12V17H14V19C14 19.5523 13.5523 20 13 20H4C3.44772 20 3 19.5523 3 19V11C3 10.4477 3.44772 10 4 10H6ZM20 4C20.5523 4 21 4.44772 21 5V15C21 15.5523 20.5523 16 20 16H8C7.44772 16 7 15.5523 7 15V5C7 4.44772 7.44772 4 8 4H20ZM19 6H9V14H19V6Z" fillRule="evenodd" clipRule="evenodd" fill="currentColor"></path>
  </svg>
);
