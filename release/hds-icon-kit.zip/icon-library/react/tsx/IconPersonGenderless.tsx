import React from 'react';

import styles from './Icon.module.css';
import { IconProps, IconSize } from './Icon.interface';

export const IconPersonGenderless = ({
  'aria-label': ariaLabel = 'person-genderless',
  'aria-hidden': ariaHidden = true,
  className = '',
  color,
  size = IconSize.Small,
  style = {},
  ...rest,
}: IconProps) => (
  <svg
    aria-label={ariaLabel}
    aria-hidden={ariaHidden}
    className={[styles.icon, styles[size], className].filter((e) => e).join(' ')}
    role="img"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    color={color}
    style={style}
    {...rest}
  >
    <path fillRule="evenodd" clipRule="evenodd" d="M11 17V22H13V17H15V24H9V17H11ZM16.5 9L17 17H15L14.7167 10.4952C14.4695 9.51758 14.0073 9.0376 13.1695 9.00213L10.9719 9C10.0691 9 9.57944 9.47848 9.32235 10.4952L9 17H7L7.5 9C7.95127 7.21543 8.98859 7.05914 10.829 7.00219L10.9719 7H13.0672C14.9908 7 16.0372 7.16967 16.5 9ZM12.0195 0C13.6764 0 15.0195 1.34315 15.0195 3C15.0195 4.59768 13.7706 5.90366 12.1958 5.99491L12 6C10.3432 6 9.00005 4.65685 9.00005 3C9.00005 1.40232 10.249 0.0963394 11.8237 0.00509271L12.0195 0ZM12.0092 2.00004L12.0195 2C11.4672 2 11.0195 2.44772 11.0195 3C11.0195 3.54891 11.4618 3.99453 12.0094 3.99995C12.5523 4 13 3.55228 13 3C13 2.45078 12.5572 2.00497 12.0092 2.00004Z" fill="currentColor"></path>
  </svg>
);
