import React from 'react';

import { IconProps } from './Icon.interface';
import styles from './Icon.module.css';

export const IconTextTool = ({
  ariaLabel = 'text-tool',
  ariaLabelledby,
  ariaHidden = true,
  className = '',
  color,
  size = 's',
  style = {},
}: React.SVGProps<SVGSVGElement> & IconProps) => (
  <svg
    className={[styles.icon, styles[size], className].filter((e) => e).join(' ')}
    role="img"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    aria-label={ariaLabel}
    aria-labelledby={ariaLabelledby}
    aria-hidden={ariaHidden}
    color={color}
    style={style}
  >
    <path fillRule="evenodd" clipRule="evenodd" d="M8 20V18H11V6H6V8H4V4H20V8H18V6H13V18H16V20H8Z" fill="currentColor"></path>
  </svg>
);
